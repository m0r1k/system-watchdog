#ifndef SYSTEM_RESTART_H
#define SYSTEM_RESTART_H

#include "system_main.h"

void do_emergency_restart(
    system_watchdog_t *a_engine
);

#endif

